const Productcard = ()=>{
    return(
        <><h1>Productcard</h1></>
    )
}

export default Productcard