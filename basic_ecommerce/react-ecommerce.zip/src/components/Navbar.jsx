const Navbar = ()=>{
    return(
        <>
        <nav className="bg-emerald-800 p-4 shadow-md ">
            <div className="max-w-2xl mx-auto flex justify-between items-center">
                <h1 className="text-white text-2xl font-normal">SmartPhone Store</h1>
                <input type="text" name="" id="" placeholder="Search Smart Phones, Brands, Colors..." className="bg-white p-3 rounded w-1/2 focus:outline-none"/>
            </div>
        </nav>
        </>
    )
}

export default Navbar