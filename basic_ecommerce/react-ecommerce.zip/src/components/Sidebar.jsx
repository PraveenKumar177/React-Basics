const Sidebar = ({brands})=>{
    return(
        <div className="w-64 bg-gray-100 p-4 h-screen sticky top-16 shadow-inner overflow-y-auto">
            <h2 className="text-xl font-bold text-emerald-800 mb-6">Filters</h2>
            {/* Brand Filter  */}
            <h3 className="font-medium text-emerald-800">Brands</h3>
            {brands.map((brand,index)=>(
                <label className="flex items-center gap-1" key={index}>
                    <input type="checkbox" className="accent-emerald-800"/>
                    {brand.charAt(0).toUpperCase()+brand.slice(1)}
                </label>
            ))}
            
            
            {/* Price Range */}
            {/* Ram */}
            {/* Storage */}
        </div>
    )
}

export default Sidebar