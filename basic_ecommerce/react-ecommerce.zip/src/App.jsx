import './App.css'
import Navbar from './components/Navbar'
import Productcard from './components/Productcard'
import Sidebar from './components/Sidebar'
import productsData from "./products.json"

function App() {
  const brands = [...new Set(productsData.map((p)=>p.brand))]
  console.log(brands)
  return (
    <>
      
      <div>
        <Navbar />
        <div>
          <Sidebar brands={brands}/>
          <div></div>
        </div>
      </div>
    </>
  )
}

export default App
